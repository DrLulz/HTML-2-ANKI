# Keep this file short to make maintenance cleaner
#  XXX (according to the addons' guidelines)

import html2anki.html_2_anki
